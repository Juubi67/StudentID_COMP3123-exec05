const express = require("express");
const app = express();
const router = express.Router();
const user = require("./user.json");

/*
- Create new html file name home.html 
- add <h1> tag with message "Welcome to ExpressJs Tutorial"
- Return home.html page to client
*/
router.get("/home", (req, res) => {
  return res.sendFile("views/home.html", { root: __dirname });
});

/*
- Return all details from user.json file to client as JSON format
*/
router.get("/profile", (req, res) => {
  return res.json(user);
});

/*
- Modify /login router to accept username and password as query string parameter
- Read data from user.json file
- If username and  passsword is valid then send resonse as below 
    {
        status: true,
        message: "User Is valid"
    }
- If username is invalid then send response as below 
    {
        status: false,
        message: "User Name is invalid"
    }
- If passsword is invalid then send response as below 
    {
        status: false,
        message: "Password is invalid"
    }
*/

router.get("/login", (req, res) => {
  try {
    const userName = req.query.username;
    const password = req.query.password;

    /* 
     Status code of 400 means bad request.
    */
    if (!userName)
      return res
        .status(400)
        .json({ status: false, message: "Please provide a user name." });

    if (!password)
      return res
        .status(400)
        .json({ status: false, message: "Please provide a password." });

    const isUserAvailable = user.username === userName;

    if (!isUserAvailable)
      return res
        .status(400)
        .json({ status: false, message: "User Name is invalid." });

    const isPasswordMatch = user.password === password;

    if (!isPasswordMatch)
      return res
        .status(400)
        .json({ status: false, message: "Password is invalid." });

    return res.status(200).json({ status: true, message: "User is valid." });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Server error" });
  }
});

/*
- Modify /logout route to accept username as parameter and display message
    in HTML format like <b>${username} successfully logout.<b>
*/
router.get("/logout/:username", (req, res) => {
  const userName = req.params.username;
  return res.send(`<b>${userName} successfull logout.</b>`);
});

app.use("/", router);

app.listen(process.env.port || 8081);

console.log("Web Server is listening at port " + (process.env.port || 8081));
